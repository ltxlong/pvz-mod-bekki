You must install dotnet 6. Download it at https://dotnet.microsoft.com/en-us/download/dotnet/6.0
If you use Windows 7 and cannot open the program, you can see https://docs.microsoft.com/zh-cn/dotnet/core/install/windows?pivots=os-windows&WT.mc_id=dotnet-35129-website&tabs=net60#additional-deps
你必须安装dotnet 6。下载地址：https://dotnet.microsoft.com/zh-cn/download/dotnet/6.0
如果win7系统打不开，请参考https://docs.microsoft.com/zh-cn/dotnet/core/install/windows?pivots=os-windows&WT.mc_id=dotnet-35129-website&tabs=net60#additional-deps